# mergematv1

Please commit changes here, but before doing so check the file here for any conflicts or changes already made by others

```
npm run dev
```

Frontend changes to be made on the app.js file, though you would have to create additional components which will be called by this file,

lastly to access the server type in any browser of your choice

```
http://localhost:3000/

```

https://www.conventionalcommits.org/en/v1.0.0-beta.2/ (use this resource to add conventional commit prefixes to your commit messages)
