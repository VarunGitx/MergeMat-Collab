module.exports = {
  testEnvironment: 'jsdom',
};

